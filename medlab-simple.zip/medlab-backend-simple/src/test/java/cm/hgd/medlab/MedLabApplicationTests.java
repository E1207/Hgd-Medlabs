package cm.hgd.medlab;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MedLabApplicationTests {

	@Test
	void contextLoads() {
	}

}
